============================================================
Dataset:	FAINA
Version:	1.0 (2025-04-30)
Authors:	Alan Ramponi, Agnese Daffara, Sara Tonelli
============================================================


--------------------
Main information
--------------------

This document outlines the terms and conditions of the dataset, as well as details on the data splits and format.

The Faina dataset has been introduced in the following paper:

	Alan Ramponi, Agnese Daffara, and Sara Tonelli. 2025. Fine-grained Fallacy Detection with Human Label Variation. In Proceedings of the 2025 Conference of the Nations of the Americas Chapter of the Association for Computational Linguistics: Human Language Technologies (Volume 1: Long Papers), pages 762–784, Albuquerque, New Mexico. Association for Computational Linguistics. URL: https://aclanthology.org/2025.naacl-long.34/

This data release is used for the FadeIT shared task at EVALITA 2026. The official website for the FadeIT shared task is at: https://sites.google.com/fbk.eu/fadeit2026


-------------------------
Terms and conditions
-------------------------

The Faina dataset is released upon request under the following terms and conditions:

	- The dataset can be used by the user(s) for non-commercial research purposes only.
	- The dataset is released in an anonymized format and the user(s) will not try to deanonymize it by any means.
	- The dataset must be used by the user(s) in compliance with current user protection regulations, and the user(s) exclude data misuse.
	- The dataset cannot be redistributed by the user(s) to third parties or in online repositories without the consent of the authors (e.g., third parties such as other individuals including students of courses or summer/winter schools, and repositories such as GitHub, Zenodo, and HuggingFace).
	- In the case of scientific outputs based on the dataset (e.g., papers, theses, models), the user(s) will properly acknowledge the paper that introduces the dataset by citing it as indicated in the "Citation" section.


-------------------------
Data splits and format
-------------------------

The Faina dataset is released in an anonymized form (i.e., with [USER], [URL], [EMAIL], and [PHONE] placeholders) with no users' information nor original post identifier to preserve their anonymity. We include individual fallacy annotations (i.e., labels assigned by each annotator) across all instances to encourage research on human label variation, as well as information about time and topics. Labels' aggregation (if needed, e.g., via majority voting) is therefore left to the user.


*** Splits ***

The Faina dataset consists of two data splits: one for training/development (data/subtask-[a|b]/train-dev.[tsv|conll]) and one for testing (data/subtask-[a|b]/test.[tsv|conll]). These have been created by paying particular attention to label, time, and topic distribution across the splits to ensure reliability in the official evaluation.

	- Training/development set (train-dev.[tsv|conll]): the split for training/development purposes (80% of the posts) with gold labels. Users are free to decide how to split this set into train/dev portions as part of their design decisions.
	- Test set (test.[tsv|conll]): the split for official testing purposes (20% of the posts) without labels. You will have to return predictions (results of the runs) to us for the official test set evaluation, following the subtask data format described in the shared task website (https://sites.google.com/fbk.eu/fadeit2026). The unlabeled test set will be given on November 27, 2025.


*** Format ***

** Subtask A: Coarse-grained fallacy detection **

The data format is in a tab-separated format and contains a header line. Each line consists of information about each post (i.e., id, date, topic, text, labels). Post-level annotations by each annotator are provided in separate columns and multiple annotations for the same post and annotator are separated by a pipe (|). Specifically, each post is represented as shown below:

	$POST_ID	$POST_DATE	$POST_TOPIC_KEYWORDS	$POST_TEXT	$LABELS_BY_ANN_A	$LABELS_BY_ANN_B

where:
	- $POST_ID: the identifier of the post (integer);
	- $POST_DATE: the date of the post (YYYY-MM);
	- $POST_TOPIC_KEYWORDS: the set in which the keyword that led to the post selection belongs (migration, climate change, or public health);
	- $POST_TEXT: the text of the post (anonymized with [USER], [URL], [EMAIL], and [PHONE] placeholders);
	- $LABELS_BY_ANN_j: the fallacy label(s) assigned by annotator j for the post (e.g., "Vagueness", "Strawman"). In the case where multiple labels for the post are assigned by the same annotator j, these are separated by a pipe (|) and ordered lexicographically, e.g., "Strawman|Vagueness". In the case where no labels for the post are assigned by the same annotator j, the label is empty.

Please note that the test set does not include gold labels (i.e., it has empty $LABELS_BY_ANN_j columns) because it serves for official evaluation only (see "Splits" section).

** Subtask B: Fine-grained fallacy detection **

The data format is based on the CoNLL format. Each post is separated by a blank line and consists of a header with post information, followed by each token in the text (with tab-separated information) separated by newlines. Token annotations follow the BIO scheme (i.e., B: begin, I: inside, O: outside) and multiple annotations for the same token and annotator are separated by a pipe (|). Specifically, each post is represented as shown below:

	# post_id = $POST_ID
	# post_date = $POST_DATE
	# post_topic_keywords = $POST_TOPIC_KEYWORDS
	# post_text = $POST_TEXT
	$TOKEN_1	$TOKEN_1_TEXT	$TOKEN_1_LABELS_BY_ANN_A	$TOKEN_1_LABELS_BY_ANN_B
	$TOKEN_2	$TOKEN_2_TEXT	$TOKEN_2_LABELS_BY_ANN_A	$TOKEN_2_LABELS_BY_ANN_B
	…			…				…							…
	$TOKEN_N	$TOKEN_N_TEXT	$TOKEN_N_LABELS_BY_ANN_A	$TOKEN_N_LABELS_BY_ANN_B

where:
	- $POST_ID: the identifier of the post (integer);
	- $POST_DATE: the date of the post (YYYY-MM);
	- $POST_TOPIC_KEYWORDS: the set in which the keyword that led to the post selection belongs (migration, climate change, or public health);
	- $POST_TEXT: the text of the post (anonymized with [USER], [URL], [EMAIL], and [PHONE] placeholders);
	- $TOKEN_i: the index of the token within the post (incremental integer);
	- $TOKEN_i_TEXT: the text of the i-th token within the post;
	- $TOKEN_i_LABELS_BY_ANN_j: the fallacy label(s) assigned by annotator j for the i-th token within the post. Each label follows the format $BIO-$LABEL, where $BIO is the BIO tag and $LABEL is the fallacy label (e.g., "Vagueness", "Strawman"), e.g., "B-Vagueness", "I-Strawman", and "O". In the case where multiple labels for the i-th token are assigned by the same annotator j, these are separated by a pipe (|) and ordered lexicographically by $LABEL, e.g., "I-Strawman|B-Vagueness". In the case where no labels for the i-th token are assigned by the same annotator j, the label is "O".

Please note that the test set does not include gold labels (i.e., it has empty $TOKEN_i_LABELS_BY_ANN_j columns) because it serves for official evaluation only (see "Splits" section).


-------------------------
Further information
-------------------------

If you need further information, do not hesitate to get in touch with us by writing a post to the Google Group or an email to fadeit2026@gmail.com.


-------------------------
Citation
-------------------------

If you refer, use or build on top of the dataset used in the context of the shared task (i.e., FAINA), please cite the following:

@inproceedings{ramponi-etal-2025-fine,
    title = "Fine-grained Fallacy Detection with Human Label Variation",
    author = "Ramponi, Alan  and
      Daffara, Agnese  and
      Tonelli, Sara",
    editor = "Chiruzzo, Luis  and
      Ritter, Alan  and
      Wang, Lu",
    booktitle = "Proceedings of the 2025 Conference of the Nations of the Americas Chapter of the Association for Computational Linguistics: Human Language Technologies (Volume 1: Long Papers)",
    month = apr,
    year = "2025",
    address = "Albuquerque, New Mexico",
    publisher = "Association for Computational Linguistics",
    url = "https://aclanthology.org/2025.naacl-long.34/",
    doi = "10.18653/v1/2025.naacl-long.34",
    pages = "762--784",
    ISBN = "979-8-89176-189-6"
}

If you refer to the FadeIT shared task in your work, please cite our paper as follows:

@inproceedings{ramponi-tonelli-2026-fadeit,
    title={{F}ade{IT} at {EVALITA} 2026: Overview of the Fallacy Detection in Italian Social Media Texts Task},
    author={Ramponi, Alan and Tonelli, Sara},
    booktitle={Proceedings of the Ninth Evaluation Campaign of Natural Language Processing and Speech Tools for Italian. Final Workshop (EVALITA 2026)},
    publisher = {CEUR.org},
    year = {2026},
    month = {February},
    address = {Bari, Italy}
}